function login(){
			$.ajax({
				url : "login.jsp",
				data : {
					username : $("#userNameTxt").val(),
					password : $("#passwordTxt").val()
				},
				success : function(response){
					if(response == "success"){
						showHomeScreen();
					}
					else
						alert(response);
				}
			});
}