function loadCountries()
{
	$.getJSON("countries.jsp","", function(response){
		$('#countries').html("");
		
		$(response.countries).each ( function() {
			$("#countries").append("<li><a href='#' >" + this  + "</li></a>");
			
		});

	});
} 